# LEGO Minifigure Faces > 2023-02-24 1:35pm
https://universe.roboflow.com/sparrowdhanashree/lego-minifigure-faces

Provided by a Roboflow user
License: CC BY 4.0

